﻿using System;

namespace Abstract
{
    class Program
    {
        static void Main(string[] args)
        {
            Eagle eagle = new Eagle();
            //eagle.Eat();
            eagle.Run();

            Shark shark = new Shark();
            //shark.Swim();
            Test test = new Test();
        }
    }

    abstract class Animal
    {
        public abstract void Eat();

        public virtual void Run()
        {
            Console.WriteLine("run as animal");
        }
    }
    abstract class Bird:Animal
    {
        public abstract void Fly();

    }

    class Eagle : Bird
    {
        public override void Eat()
        {
            Console.WriteLine("eat as eagle");
        }

        public override void Fly()
        {
            Console.WriteLine("fly as eagle"); ;
        }
        public override void Run()
        {
            Console.WriteLine("run as eagle") ; 
        }
    }

    abstract class Fish : Animal
    {
        public abstract void Swim();
    }

    class Shark : Fish
    {
        public override void Eat()
        {
            Console.WriteLine("eat as shark");
        }

        public override void Swim()
        {
            Console.WriteLine("swim as Shark");
        }
    }
    interface ICalculate
    {
       
        void Minus(int num1, int num2);
        void Divide(int num1, int num2);
        void Multiple(int num1, int num2);
        
    }
    interface IPlus
    {
        void Plus(int num1, int num2);
        
    }
    interface IMinus
    {
        void Minus(int num1, int num2);
    }
    class Person : IPlus,IMinus
    {
        public void Minus(int num1, int num2)
        {
            throw new NotImplementedException();
        }

        public void Plus(int num1, int num2)
        {
            throw new NotImplementedException();
        }
    }

     abstract class Person1
    {
        public virtual void Knowlodge()
        {
            Console.WriteLine("nothing");
        }
    }
    class Developer : Person1
    {
        public sealed override void Knowlodge()
        {
            Console.WriteLine("c# js");  
        }
    }
    class FrontEnd:Developer
    {

    }
}
